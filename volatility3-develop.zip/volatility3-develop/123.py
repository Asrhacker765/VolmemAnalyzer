import ctypes

# Get a handle to the process
PROCESS_ALL_ACCESS = 0x1F0FFF
pid = 1234  # The process ID of the process you want to access
handle = ctypes.windll.kernel32.OpenProcess(PROCESS_ALL_ACCESS, False, pid)

# Read the memory
buffer = ctypes.create_string_buffer(4096)
bytes_read = ctypes.c_ulong(0)
address = 0x7ffe0000  # The address where you want to start reading

ctypes.windll.kernel32.ReadProcessMemory(handle, address, buffer, 4096, ctypes.byref(bytes_read))

print(buffer.raw)