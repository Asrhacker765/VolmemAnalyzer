import subprocess
import time

def capture_memory(duration, image_path):
    start_time = time.time()
    while True:
        current_time = time.time()
        elapsed_time = current_time - start_time
        if elapsed_time > duration:
            break
        # Replace 'profile' with the profile appropriate for your system
        # Replace 'plugin' with the Volatility plugin you want to use
        cmd = f"volatility -f {image_path} --profile=Win7SP1x64 pslist"
        output = subprocess.check_output(cmd, shell=True)
        with open('memory_dump.txt', 'a') as f:
            f.write(output.decode())
        time.sleep(1)  # wait for 1 second before the next memory dump

# Call the function with the duration in seconds and the path to your memory image
capture_memory(60, "C:\\Users\\sisod\\OneDrive\\Desktop\\volatility3-develop\\vol.py")  # captures memory for 60 seconds