import subprocess
import os
import ctypes
import sys

def is_admin():
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except:
        return False

def create_memory_dump(winpmem_path, output_file):
    try:
        # Ensure output directory exists
        os.makedirs(os.path.dirname(output_file), exist_ok=True)
        
        # Use the appropriate option to capture only volatile memory
        result = subprocess.run([winpmem_path, output_file], check=True, capture_output=True, text=True)
        print("Memory dump created successfully.")
        return True
    except subprocess.CalledProcessError as e:
        print(f"An error occurred while capturing memory dump: {e}")
        print(f"Return code: {e.returncode}")
        print(f"Output: {e.output}")
        print(f"Error output: {e.stderr}")
        return False

def analyze_memory_dump(volatility_path, output_dir):
    analyzer_script = os.path.join(volatility_path, "volatility_memory_analyzer.py")
    memory_dump_file = os.path.join(output_dir, "memory_dump.raw")

    try:
        result = subprocess.run(
            ['python', analyzer_script, '-f', memory_dump_file, '-o', output_dir, '-V', volatility_path], 
            check=True, capture_output=True, text=True
        )
        print("Memory dump analyzed successfully.")
        print(result.stdout)
        return True
    except subprocess.CalledProcessError as e:
        print(f"An error occurred while analyzing memory dump: {e}")
        print(f"Return code: {e.returncode}")
        print(f"Output: {e.output}")
        print(f"Error output: {e.stderr}")
        return False

if __name__ == "__main__":
    if not is_admin():
        print("Script not running as administrator. Exiting.")
        # Re-run the script with admin privileges
        ctypes.windll.shell32.ShellExecuteW(None, "runas", sys.executable, ' '.join(sys.argv), None, 1)
        sys.exit()

    winpmem_path = "C:\\Users\\sisod\\OneDrive\\Desktop\\winpmem\\winpmem_mini.exe"
    output_file = "C:\\Users\\sisod\\OneDrive\\Desktop\\dump\\memory_dump.raw"
    volatility_path = "C:\\Users\\sisod\\OneDrive\\Desktop\\volatility3-develop"
    output_dir = "C:\\Users\\sisod\\OneDrive\\Desktop\\dump"

    if create_memory_dump(winpmem_path, output_file):
        analyze_memory_dump(volatility_path, output_dir)
