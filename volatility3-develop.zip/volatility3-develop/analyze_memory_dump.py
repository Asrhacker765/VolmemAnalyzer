import subprocess

def analyze_memory_dump(analyzer_script, memory_dump_file, output_dir, volatility_path):
    try:
        subprocess.run(['python', analyzer_script, '-f', memory_dump_file, '-o', output_dir, '-V', volatility_path], check=True)
        print("Memory dump analyzed successfully.")
    except subprocess.CalledProcessError as e:
        print(f"An error occurred while analyzing memory dump: {e}")
        print(f"Error details: {e.stderr}")
